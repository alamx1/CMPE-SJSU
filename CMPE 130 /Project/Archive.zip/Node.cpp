#include <iostream>

#include "Node.h"

void Node(){
  vertex = 0;
  weight = 0;
  next = NULL;
}

void Node(int vrtx, int wght){
  vertex = vrtx;
  weight = wght;
  next = NULL;
  //next = nxt;
}


